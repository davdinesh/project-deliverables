export class ViewUsers {
  userId: number;
  firstName: string;
  lastName: string;
  employeeId: number;
}
