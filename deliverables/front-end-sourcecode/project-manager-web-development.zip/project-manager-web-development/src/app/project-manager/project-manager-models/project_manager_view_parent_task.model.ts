export class ViewParentTasks {
  parentId: number;
  parentDesc: string;
}
