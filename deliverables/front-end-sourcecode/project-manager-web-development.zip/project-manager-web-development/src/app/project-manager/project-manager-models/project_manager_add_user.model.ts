export class AddUser {
  firstName: string;
  lastName: string;
  employeeId: number;
}
