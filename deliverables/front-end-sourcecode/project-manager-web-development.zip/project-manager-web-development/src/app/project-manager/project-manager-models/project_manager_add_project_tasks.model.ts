
export class AddProjectTasks {
  projectName: string;
  projectStartDate: Date;
  projectEndDate: Date;
  userId: number;
  priority: number;
  status: string;
  completeTasks: number;
  totalTasks: number;
}
