export class AddParentTasks {
  parentDesc: string;
}
